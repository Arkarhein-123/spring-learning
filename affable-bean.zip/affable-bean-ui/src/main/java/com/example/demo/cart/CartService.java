package com.example.demo.cart;

import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;

import com.example.demo.dto.ProductDto;

@Service
public class CartService {

    private final CartRepository cartRepository;

    // 1. Clean Constructor: Only inject dependencies
    public CartService(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }

    public Cart getMyCart() {
        String sessionId = getBrowserSessionId();
        return cartRepository.findById(sessionId)
                .orElseGet(() -> {
                    Cart newCart = new Cart();
                    newCart.setId(sessionId);
                    // Don't necessarily need to save yet, just return it
                    return newCart;
                });
    }

    public void addToCart(ProductDto productDto) {
        String sessionId = getBrowserSessionId();
        
        // 2. Find or Create logic
        Cart cart = cartRepository.findById(sessionId)
                .orElseGet(() -> {
                    Cart newCart = new Cart();
                    newCart.setId(sessionId);
                    return newCart;
                });

        cart.addItem(toCartItem(productDto));
        
        // 3. Save to Redis/DB
        cartRepository.save(cart);
    }

    private CartItem toCartItem(ProductDto productDto) {
        return new CartItem(
                productDto.id(),
                productDto.name(),
                productDto.price(),
                1
        );
    }

    private String getBrowserSessionId() {
        return RequestContextHolder
                .currentRequestAttributes()
                .getSessionId();
    }
}
