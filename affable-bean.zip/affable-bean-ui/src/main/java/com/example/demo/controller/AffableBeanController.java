package com.example.demo.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.cart.CartService;
import com.example.demo.dto.ProductDto;
import com.example.demo.service.AffableBeanService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/affable-bean/ui")
public class AffableBeanController {
	private final AffableBeanService affableBeanService;
	private final CartService cartService;
	
	private String currentCategoryName;
	
	@GetMapping("/home")
	public String home() {
		return "home";
	}
	
	@GetMapping("/cart-view")
	public String viewCart(Model model) {
		model.addAttribute("cartItems",cartService.getMyCart().getItems());
		return "cart-view";
	}
	
	// /affable-bean/ui/add-to-cart?id=2
	@GetMapping("/add-to-cart")
	public String addToCart(@RequestParam("id") Long id) {
	    ProductDto productDto = affableBeanService.getProductById(id);
	    cartService.addToCart(productDto);
	    
	    // Fallback if currentCategoryName is null
	    String category = (currentCategoryName != null) ? currentCategoryName : "dairy";
	    return "redirect:/affable-bean/ui/products?name=" + category;
	}
	
	// /affable-bean/ui/products?name=
	@GetMapping("/products")
	public String listProducts(@RequestParam("name")String name,Model model) {
		model.addAttribute("products",affableBeanService.listAllProducts(name));
		currentCategoryName = name;
		return "products";
	}
	
	@ModelAttribute("cartSize")
	public int cartSize() {
		return cartService.getMyCart().getItems().size();
	}
	
}
